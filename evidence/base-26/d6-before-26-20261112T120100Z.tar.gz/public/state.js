import {situations,lights} from './data.js';
import {validate as validateLegacy} from './legacy.js';
const owns=(o,k)=>Object.hasOwn(o,k);const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const empty=()=>({version:4,situation:null,lights:[],done:false,legacy:null});
export {empty};
export function validate(x){if(!isObj(x))return null;if([1,2,3].includes(x.version)){const old=validateLegacy(x);if(!old)return null;let person=old.personal||old.draft;let map={dawn:'ambient',arc:'ambient',pause:'ambient',focus:'task',line:'task',halo:'accent',fold:'accent',point:'accent'};let selected=[...new Set((person?.modules||[]).map(id=>map[id]).filter(Boolean))];return {version:4,situation:person?.scenario?({work:'work',rest:'evening',meeting:'meeting'}[person.scenario]||null):null,lights:selected,done:false,legacy:x};}
 if(x.version!==4||Object.keys(x).sort().join(',')!=='done,legacy,lights,situation,version'||!(x.situation===null||owns(situations,x.situation))||!Array.isArray(x.lights)||x.lights.some(id=>!owns(lights,id))||new Set(x.lights).size!==x.lights.length||typeof x.done!=='boolean'||(!x.situation&&(x.lights.length||x.done))||(x.done&&!x.lights.length)||!(x.legacy===null||validateLegacy(x.legacy)))return null;
 return {version:4,situation:x.situation,lights:[...x.lights],done:x.done,legacy:x.legacy};}
export function chooseSituation(s,id){if(!owns(situations,id))return s;const defaults={evening:['ambient','accent'],work:['ambient','task'],meeting:['ambient','accent']};return {...s,situation:id,lights:s.situation?s.lights:defaults[id],done:false};}
export function toggle(s,id){if(!s.situation||!owns(lights,id))return s;return {...s,lights:s.lights.includes(id)?s.lights.filter(x=>x!==id):[...s.lights,id],done:false};}
export function finish(s){return s.situation&&s.lights.length?{...s,done:true}:s;}
